package org.example;

public class Saludo {
public String imprimirSaludo(){
System.out.println("Buenos días!!");
    return null;
}
}
